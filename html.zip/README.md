# ogt-linkedin

1. Setup config.php
2. Install Composer
3. Install dependencies (https://www.srijan.net/blog/integrating-google-sheets-with-php-is-this-easy-know-how)
4. Create credentials.json (https://www.srijan.net/blog/integrating-google-sheets-with-php-is-this-easy-know-how)

